export default function Profile() {
  return (
    <div>
      <h2>Profile</h2>
      <p>Your experience level, ZIP prefix, and optional contact will appear here.</p>
    </div>
  );
}
