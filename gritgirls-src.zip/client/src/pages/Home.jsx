export default function Home() {
  return (
    <div>
      <h2>Home</h2>
      <p>Welcome! This is the pilot for a women’s MTB community.</p>
    </div>
  );
}
