export default function Rides() {
  return (
    <div>
      <h2>Rides</h2>
      <p>Ride listings and RSVPs will go here.</p>
    </div>
  );
}
